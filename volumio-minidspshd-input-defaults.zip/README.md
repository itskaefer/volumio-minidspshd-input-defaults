# volumio-minidspshd-input-default
Volumio plugin to set default values for volume and preset by input


